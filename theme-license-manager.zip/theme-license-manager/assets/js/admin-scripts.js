// Custom JavaScript for the Theme License Manager plugin
(function($) {
    $(document).ready(function() {
        // Example: Show a confirmation dialog before deleting the license key
        $('#delete-license-button').on('click', function(e) {
            if (!confirm('Are you sure you want to delete the license key?')) {
                e.preventDefault();
            }
        });
    });
})(jQuery);
