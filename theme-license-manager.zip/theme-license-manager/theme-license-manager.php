<?php
// The namespace declaration must be the first thing
namespace ThemeLicenseManager;

/*
Plugin Name: Theme License Manager (Custom Table)
Description: A plugin to display and edit the hidden license key of a premium WordPress theme stored in a custom table.
Version: 1.1
Author: Ayeet Daniel Onyanga
Text Domain: theme-license-manager
License: GPL2
*/

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Add hooks and actions within the namespace
use wpdb;

// Create admin menu for the plugin
add_action('admin_menu', __NAMESPACE__ . '\\theme_license_manager_menu');

function theme_license_manager_menu() {
    add_menu_page(
        __('Theme License Manager', 'theme-license-manager'),  // Page title (translatable)
        __('License Manager', 'theme-license-manager'),        // Menu title (translatable)
        'manage_options',                                      // Capability
        'theme-license-manager',                               // Menu slug
        __NAMESPACE__ . '\\theme_license_manager_page'         // Callback function
    );
}

// Admin page for displaying and editing the license key
function theme_license_manager_page() {
    global $wpdb;

    // Check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Name of the theme we are working with (you can make this dynamic)
    $theme_name = 'your_theme_name'; // Replace with your theme name
    
    // Custom table name (use the $wpdb->prefix to prevent conflicts)
    $table_name = $wpdb->prefix . 'theme_licenses';

    // Handle form submission for license key update
    if ( isset( $_POST['theme_license_key'] ) ) {
        // Security check
        check_admin_referer('update_theme_license_key', 'theme_license_manager_nonce');

        // Validate and sanitize input
        $new_license_key = sanitize_text_field( $_POST['theme_license_key'] );

        // Update or insert the license key in the custom table
        $wpdb->replace( 
            $table_name, 
            array( 
                'theme_name' => $theme_name, 
                'license_key' => $new_license_key 
            ), 
            array( '%s', '%s' ) 
        );

        echo '<div class="notice notice-success"><p>' . __('License key updated successfully.', 'theme-license-manager') . '</p></div>';
    }

    // Retrieve the existing license key from the custom table
    $stored_license_key = $wpdb->get_var( 
        $wpdb->prepare( 
            "SELECT license_key FROM $table_name WHERE theme_name = %s", 
            $theme_name 
        ) 
    );

    // Escape output for security
    $stored_license_key = esc_attr( $stored_license_key );

    ?>
    <div class="wrap">
        <h1><?php _e('Manage Theme License Key', 'theme-license-manager'); ?></h1>
        <form method="POST">
            <?php wp_nonce_field('update_theme_license_key', 'theme_license_manager_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="theme_license_key"><?php _e('License Key', 'theme-license-manager'); ?></label></th>
                    <td><input type="text" name="theme_license_key" id="theme_license_key" value="<?php echo $stored_license_key; ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button( __('Save License Key', 'theme-license-manager') ); ?>
        </form>
    </div>
    <?php
}

// Hook to retrieve license key for other purposes (if needed)
function get_theme_license_key() {
    global $wpdb;
    $theme_name = 'your_theme_name';  // Replace with your theme name
    $table_name = $wpdb->prefix . 'theme_licenses';

    // Retrieve and escape the license key from the custom table
    $license_key = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT license_key FROM $table_name WHERE theme_name = %s", 
            $theme_name 
        )
    );

    return esc_attr( $license_key );
}

// Uninstall hook to remove custom table data on plugin deletion
register_uninstall_hook(__FILE__, __NAMESPACE__ . '\\theme_license_manager_uninstall');

function theme_license_manager_uninstall() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'theme_licenses';

    // Delete the custom table
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
